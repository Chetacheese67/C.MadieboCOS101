// Bookshop Order System

fn main() {



 
	let mut input1 = String::new();
	let mut input2 = String::new();

	// Menu System

	println!("Welcome To Teccna Bookshop
		\n R    Rust For Begginers         -15 000
		\n A    All basics                 -12 500
		\n D    Data Structures in Rust    -20 000
		\n N    Networking Essentials      -18 000 ");
	io:stdn().read_line(&mut input1).expect("Not a valid string");
	
	
let mut total = String::new

if input1 = r {
	total = 15000
}

if input1 = a {
	total = 12500
}

if input1 = d {
	total = 20000
}

if input1 = n {
	total = 18000
}
println!("How many?")
	io:stdn().read_line(&mut input2).expect("Not a valid string");
	let amount:f32 = input2.trim().parse().expect("Not a valid number");

	let mut complete_total = String::new

	complete_total = (total * amount)

if amount > 3 {
let complete_total = (total * amount * 0.1)

}


}
